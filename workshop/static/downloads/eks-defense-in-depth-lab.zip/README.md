# A Layered Approach to Amazon EKS Security

[Đọc workshop trên GitHub Pages](https://toannd021104.github.io/AWS-Security-Workshop-EKS-defense-in-dept/).

Workshop tiếng Việt, tập trung từ Internet đến pod, Kubernetes workload security, IAM/RBAC và supply chain/data security. Bản mới được chắt lọc từ `../test.md`; không sửa bản gốc hoặc site `../AWS-Security-WS`.

ZIP tải từ website chỉ gồm mã lab. Để chạy/chỉnh Hugo, clone toàn bộ repository.

## Đọc và chạy website

```bash
hugo server --source workshop --bind 0.0.0.0 --port 1314
```

Mở http://localhost:1314/. Năm module gồm 26 bài, có preparation, validation và cleanup riêng. Hướng dẫn ưu tiên Console → AWS CLI/API → Terraform. Slide, threat detection và incident response ngoài phạm vi.

## Chuẩn bị lab từ đầu

[Chuẩn bị lab trên website](https://toannd021104.github.io/AWS-Security-Workshop-EKS-defense-in-dept/preparation/) có 9 trang: sau công cụ/tài khoản, chọn ngay Terraform để tạo toàn bộ hạ tầng hoặc Console để tạo từng thành phần (VPC → EKS/nodes → RDS/SQS/ECR → certificate/WAF → workload permissions). Terraform thay thế các bước Console 0.2–0.6; cả hai nhánh tiếp tục ở build/deploy → baseline. Nhánh Console không cần đọc vòng sang chương 2 hoặc 4 để có ứng dụng chạy được.

Sau bước baseline mới bắt đầu chương 2. Mỗi lệnh kiểm tra có output mẫu và ý nghĩa; `APP_HOST` được giải thích từ lúc thu thập cấu hình thay vì giả định đã có sẵn.

## Triển khai lab bằng Terraform

AWS CLI profile `guru`, region `us-east-1`. Kiểm tra `aws sts get-caller-identity` trước. Cần domain public Route 53 có delegation hợp lệ cho HTTPS.

```bash
export AWS_PROFILE=guru AWS_REGION=us-east-1
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements-lab.txt
cp infrastructure/terraform/terraform.tfvars.example infrastructure/terraform/terraform.tfvars
# Sửa admin_cidr /32 và dns_zone_name. Không dùng nguyên địa chỉ minh họa.
terraform -chdir=infrastructure/terraform init
terraform -chdir=infrastructure/terraform validate
terraform -chdir=infrastructure/terraform plan -out=lab.tfplan
terraform -chdir=infrastructure/terraform apply lab.tfplan
source scripts/env.sh
python3 scripts/capture-config.py
source scripts/env.sh
bash scripts/build-push.sh
bash scripts/deploy.sh
python3 scripts/publish-dns.py
```

Đợi DNS public và targets healthy trước khi chạy test. Mọi cách Console/CLI/Terraform đều dùng cùng tên `eks-did` và naming subnet đã ghi trong trang preparation; không cần state Terraform để render khi chọn Console.

## Supply chain và validation

```bash
bash scripts/supply-chain.sh
bash scripts/admission.sh
bash scripts/prepare-unsigned.sh
python3 scripts/verify.py --supply-chain
# Gate trả exit 1 nếu scan chưa hoàn tất hoặc còn HIGH/CRITICAL:
python3 scripts/scan-gate.py
```

`prepare-unsigned.sh` tạo digest khác chỉ dùng làm negative admission test; không deploy image đó. Signing key private nằm trong `.local/`, public key trong `k8s/cosign.pub`. ECR verification token có hạn khoảng 12 giờ; refresh qua admission script. Kyverno ClusterPolicy dùng API legacy còn được hỗ trợ ở release đã pin, cần đánh giá migration ImageValidatingPolicy khi nâng cấp.

Kết quả public nằm trong `evidence/verification.json` và trang validation. `.local` giữ log, kubeconfig và dữ liệu nhạy cảm: không publish. Console screenshots thực tế được chụp bằng phiên chỉ đọc; thông tin đăng nhập không được đưa lên website.

## Cách tổ chức bài học

Trang chủ đặt bối cảnh Notes, mục tiêu và lộ trình. Trang chương nêu trạng thái đầu vào, công việc và bằng chứng cần có. Các bài thực hành giải thích khái niệm tại bước cần dùng, dùng tiêu đề hành động cụ thể và đối chiếu kết quả sau thao tác; ưu tiên Console, dùng CLI/API khi cần và liên kết Terraform tương ứng. Trang Tổng kết đối chiếu các lớp bảo vệ và giới hạn của lab. Cách dẫn bài và bố cục tham khảo AWS Workshop Studio; website vẫn là Hugo trên GitHub Pages, không phải workshop chính thức của AWS.

Bài NetworkPolicy có phép thử độc lập, không áp dụng hoặc xóa policy trong lúc kiểm chứng:

```bash
# Chỉ trên baseline chưa có NetworkPolicy:
python3 scripts/network-proof.py --stage before
# Sau khi áp dụng k8s/network-policies.yaml:
python3 scripts/network-proof.py --stage after
```

Mười sáu ảnh Console được dùng trong bài, có khoanh đỏ/đánh số ở các trường cần đối chiếu. Nguồn ảnh và cách chú thích được ghi trong `evidence/console-screenshots.json`.

## Chỉnh sửa nội dung và sơ đồ

- Trang Markdown chuẩn nằm trong `workshop/content/`.
- `scripts/preparation_content.py` chứa nội dung 9 trang chuẩn bị; `scripts/write_workshop.py` là nguồn sinh bản nội dung workshop; nếu sửa Markdown trực tiếp, không chạy lại generator vì nó ghi đè các trang đó. Các thay đổi bản gốc nên sửa trong generator rồi sinh lại để đồng bộ.
- `scripts/diagrams.py` sinh SVG và draw.io từ icon AWS/Kubernetes ở `/home/ubuntu/devops-blog2/src/assets/icons/`. Artifacts đã có trong repo nên build Hugo không cần thư mục icon ngoài.
- `k8s/application.yaml` và `network-policies.yaml` là manifests đã render. Người dùng account khác chạy `capture-config.py`, build-push và render lại, không áp dụng endpoint/ARN của account ví dụ.
- Website chỉ mount allowlisted Terraform source, app/scripts và manifests; không mount `.local` hoặc state.

## Cleanup và chi phí

```bash
source scripts/env.sh
python3 scripts/cleanup.py
terraform -chdir=infrastructure/terraform plan -destroy -out=destroy.tfplan
terraform -chdir=infrastructure/terraform apply destroy.tfplan
```

Review đúng account và tài nguyên lab. Cleanup xóa Ingress trước để controller gỡ ALB; sau đó mới destroy VPC. RDS disposable không giữ final snapshot, ECR force-delete images; đừng dùng cho dữ liệu cần giữ. Inspector là account-level setting; chỉ tắt khi chính lab bật và không có consumer khác. CMK schedule deletion 7 ngày.

EKS, EC2, ALB, NAT/public IPv4, RDS, WAF, Inspector và KMS tiếp tục tính phí khi để lab chạy. Hai node/private subnets không làm toàn hệ thống HA: lab dùng một NAT, Single-AZ RDS và một replica controller/admission để giảm chi phí.

## English and Vietnamese editions

The default Vietnamese edition keeps its existing URLs. English lessons are at `/en/`; use VI / EN in the header to switch to the same lesson. Both editions include all 46 pages, localized navigation/search/captions, and English diagram labels with matching SVG/draw.io sources.

English content is authored in `_index.en.md` beside each Vietnamese page. The Vietnamese generators preserve these files; update both editions when changing an instruction, and run `python3 scripts/check_translations.py` before publishing. The verifier writes observed results in both languages. Regenerate English diagrams with `python3 scripts/diagrams.py --language en`.

Website checks apply to the full repository (the lab ZIP contains runnable lab source):

```bash
.local/bin/hugo --source workshop --destination ../.local/site --baseURL http://localhost:1314/
python3 scripts/check_site.py --site .local/site
```

Use your installed Hugo Extended executable if it is not at `.local/bin/hugo`. The learner review dated 2026-11-14 runs local/static checks only; its report is in `evidence/learner-review-2026-11-14.md`. The 2026-11-13 AWS results remain historical evidence, not a new cloud run after the environment stopped.
